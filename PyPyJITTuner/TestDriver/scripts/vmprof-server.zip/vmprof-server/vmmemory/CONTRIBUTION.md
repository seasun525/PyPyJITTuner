This module has mostly been developed by Jonas Haag, supported by Blue Yonder (blue-yonder.com).
